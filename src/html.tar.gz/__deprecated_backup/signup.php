
<?php

include("config.php");
include("functions.php");

session_start();


// load variables from post
if($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = sanitize($_POST["username"]);
        $name = sanitize($_POST["name"]);
        $email = sanitize($_POST["email"]);
        $password = sanitize($_POST["password"]);
        $rpassword = sanitize($_POST["rpassword"]);
        $cc = sanitize($_POST["cc"]);
}


// get user's data from database
// FIXME prepare query before using it
$sql = "select * from user where username=".$username;
$result = $connection->query($sql);
if(!$result) {
        print_error("failed query:(".$sql.")");
        exit();
}

// check if user exists
if($result->rowCount() > 0) {
        print_error("username already exists.");
        $connection = null;
        exit();
}

// FIXME verify strength of password
switch() {
	//FIXME diferent values for too short, invalid chars, etc
}

// check if passwords match
if($password != $rpassword) {
        print_error("passwords do not match.");
        $connection = null;
        exit();
}

$password = hash($password);

// insert values in database
$sql = "INSERT INTO user (username,password,name,email,cc) VALUES ('$username','$password','$name','$email','$cc')";
$result = $connection->query($sql);
if(!$result) {
        print_error("failed query:(".$sql.")");
        exit();
}


// imidiate login
$_SESSION["id"] = $id;
$_SESSION["username"] = $username;



?>




