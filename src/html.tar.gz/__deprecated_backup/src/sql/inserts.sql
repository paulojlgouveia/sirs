
DELIMITER ;

SET foreign_key_checks = 0 ;


TRUNCATE TABLE user;
TRUNCATE TABLE item;
TRUNCATE TABLE auction;


SET foreign_key_checks = 1 ;


INSERT INTO user (username,name,email,password) VALUES
("admin","administrator","admin@webserver.com",SHA2("admin",256)),
("guest","guest user","guest@webserver.com",SHA2("guest",256));


