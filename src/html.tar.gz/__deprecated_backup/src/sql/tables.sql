
-- mysql -u root -p
-- ju57 50m3 p455w0rD

SET foreign_key_checks = 0 ;


DROP TABLE IF EXISTS user ;
CREATE TABLE user(
	id		INT NOT NULL AUTO_INCREMENT,
	username	VARCHAR(20) NOT NULL,
	name		VARCHAR(80) NOT NULL,
	email		VARCHAR(50),
	password	CHAR(64) NOT NULL,
	cc		INT,

	PRIMARY KEY (id)
);


DROP TABLE IF EXISTS item ;
CREATE TABLE item(
	id		INT NOT NULL AUTO_INCREMENT,
	name		VARCHAR(80) NOT NULL,
--	owner		foreign_key?
	description	VARCHAR(50),

	PRIMARY KEY (id)
);


DROP TABLE IF EXISTS auction ;
CREATE TABLE auction(
	id		INT NOT NULL AUTO_INCREMENT,
--	item		foreign_key?
--	owner		foreign_key?
	base_value	INT NOT NULL,
	value		INT NOT NULL,

	PRIMARY KEY (id)
);


SET foreign_key_checks = 1 ;



