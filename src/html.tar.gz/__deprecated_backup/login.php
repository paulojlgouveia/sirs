
<?php
error_reporting(E_ALL | E_WARNING | E_NOTICE);
ini_set('display_errors', TRUE);


flush();
header('Location: home.php');
die('should have redirected by now');


include("config.php");
include("functions.php");

session_start();




// load variables from post
if($_SERVER["REQUEST_METHOD"] == "POST") {
	$username = sanitize($_POST["username"]);
	$password = hash(sanitize($_POST["password"]));
}


// get user's data from database
// FIXME prepare query before using it
$sql = "select * from user where username=".$username;
$result = $connection->query($sql);
if(!$result) {
	print_error("<p> Erro na Query:($sql)<p>");
	exit();
}

// checks if user exists
if($result->rowCount() == 0) {
	print_error("username does not exist.");
	$connection = null;
	echo("<a href=\"home.html\">return</a>");
	exit();
}

// extract info from query's result
$result = $result->fetch();
$id = $result["id"];
$pass = $result["password"];
$user = $result["username"];

// verify password
if($pass != $password) {
        print_error("wrong password.");
	$connection = null;
	echo("<a href=\"home.html\">return</a>");
	exit();
}

// pass the values into the session
$_SESSION["id"] = $id;
$_SESSION["username"] = $username;

header('Location:home.php');


?>




