
-- mysql -u root -p
-- ju57 50m3 p455w0rD

use auctionsDB;

SET foreign_key_checks = 0 ;


DROP TABLE IF EXISTS user ;
CREATE TABLE user(
	id			INT NOT NULL AUTO_INCREMENT,
	username	VARCHAR(20) NOT NULL,
	password	CHAR(64) NOT NULL,
	level		INT NOT NULL DEFAULT 1,
	name		VARCHAR(80) NOT NULL,
	email		VARCHAR(50),
	cc			INT,

	PRIMARY KEY (id)
);


DROP TABLE IF EXISTS item ;
CREATE TABLE item(
	id			INT NOT NULL AUTO_INCREMENT,
	name		VARCHAR(80) NOT NULL,
	owner_id	INT NOT NULL,
	description	VARCHAR(50),

	PRIMARY KEY (id),
	FOREIGN KEY (owner_id) REFERENCES user(id)

);


DROP TABLE IF EXISTS auction ;
CREATE TABLE auction(
	id			INT NOT NULL AUTO_INCREMENT,
	item_id		INT NOT NULL,
	auctioneer	INT NOT NULL,
	base_value	INT NOT NULL,
	value		INT NOT NULL,

	PRIMARY KEY (id),
	FOREIGN KEY (auctioneer) REFERENCES user(id),
	FOREIGN KEY (item_id) REFERENCES item(id)
);


SET foreign_key_checks = 1 ;



