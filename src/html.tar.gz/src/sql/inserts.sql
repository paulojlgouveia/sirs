
DELIMITER ;

SET foreign_key_checks = 0 ;


TRUNCATE TABLE user;
TRUNCATE TABLE item;
TRUNCATE TABLE auction;


SET foreign_key_checks = 1 ;


INSERT INTO user (username,password,level,name,email) VALUES
("admin",SHA2("admin",256),2,"administrator","admin@webserver.com"),
("guest",SHA2("guest",256),0,"guest user","guest@webserver.com");


