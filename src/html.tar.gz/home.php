
<!doctype html>

<?php
	session_start();
?>

<html>
	<title>Auction</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="src/css/login.css">
	
	<body>
		<h1>home page</h1>
		
		<?php require($DOCUMENT_ROOT . "header.html"); ?>
		
		<?php if (!isset($_SESSION['id'])) {
				require($DOCUMENT_ROOT . "navigation.php");
			} else {
				echo "loged in.";
		} ?>

		
		<?php require($DOCUMENT_ROOT . "footer.html"); ?>
		
		


	</body>
	
</html>



