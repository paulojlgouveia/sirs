
<?php


// hashing function
function hash($data) {
	$result = hash("sha256", $data);
	return $result;
}


// input sanitization
function sanitize($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	$data = mysql_real_escape_string($data);                                
	return $data;
}


// cleans and displays an error message
function print_error($message) {
	echo("<p>".$message."</p>");
}




?>



