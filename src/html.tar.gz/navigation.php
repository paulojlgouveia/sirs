

<?php if (!isset($_SESSION['username'])): ?>

		<button onclick="document.getElementById('flogin').style.display='block'" style='width:auto;'>Login</button>
		<button onclick="document.getElementById('fsignup').style.display='block'" style='width:auto;'>Sign Up</button>
		
				<!-- login form-->
		<div id="flogin" class="modal">
			<form class="modal-content animate" action="login.php" method="post">
				<div class="imgcontainer">
					<span onclick="document.getElementById('flogin').style.display='none'" class="close" title="Close Modal">&times;</span>
					<img src="img/avatar_default.jpg" alt="Avatar">
				</div>
				
				<div class="imgcontainer">guest : guest</div>
				
				<div class="container">
					<label><b>Username</b></label>
					<input type="text" placeholder="Enter Username or guest" name="username" required>
					
					<label><b>Password</b></label>
					<input type="password" placeholder="Enter Password or guest" name="password" required>
					<button type="submit">Login</button>
					<input type="checkbox" checked="checked"> Remember me
				</div>
				
				<div class="container" style="background-color:#f1f1f1">
					<button type="button" onclick="document.getElementById('flogin').style.display='none'" class="cancelbtn">Cancel</button>
					<span class="psw">Forgot <a href="#">password</a>?</span>
				</div>
			</form>
		</div>
		
		<!-- signup form-->
		<div id="fsignup" class="modal">
			<form class="modal-content animate" action="signup.php" method="post">
				<div class="imgcontainer">
					<span onclick="document.getElementById('fsignup').style.display='none'" class="close" title="Close Modal">&times;</span>
				</div>
				
				<div class="container">
					<label><b>Username</b></label>
					<input type="text" placeholder="Enter username" name="username" required>
					
					<label><b>Name</b></label>
                    <input type="password" placeholder="Enter your name" name="name" required>

					<label><b>Email</b></label>
                    <input type="password" placeholder="Enter your email address" name="email" required>

					<label><b>Password</b></label>
					<input type="password" placeholder="Enter password" name="password" required>
					
					<label><b>Retipe password</b></label>
                    <input type="password" placeholder="Retipe your password" name="rpassword" required>

					<label><b>Credit Card</b></label>
                    <input type="password" placeholder="Enter your credit card number" name="cc" required>


					<button type="submit">Register</button>
				</div>

				<div class="container" style="background-color:#f1f1f1">
					<button type="button" onclick="document.getElementById('fsignup').style.display='none'" class="cancelbtn">Cancel</button>
				</div>
			</form>
		</div>
		
		<script>
			// Get the modal
			var signup_form = document.getElementById('fsignup');		
			var login_form = document.getElementById('flogin');

			// When the user clicks anywhere outside of the modal, close it
			window.onclick = function(event) {
				if (event.target == signup_form) {
					signup_form.style.display = "none";
				}
				
				if (event.target == login_form) {
					login_form.style.display = "none";
				}
			}
		</script>
		
<?php else: ?>

		<button onclick="logout.php" style='width:auto;'>Logout</button>
		
<?php endif; ?>


		
		
		
		
		