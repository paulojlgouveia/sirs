
<?php


	// hashing function FIXME bcrypt
	function encrypt($data) {
		$result = hash("sha256", $data);
		return $result;
	}


	// input sanitization FIXME
	function sanitize($data) {
// 		$data = trim($data);
// 		$data = stripslashes($data);
// 		$data = htmlspecialchars($data);
// 		$data = mysql_real_escape_string($data);
		return $data;
	}


	// cleans and displays an error message FIXME
	function log_pdo_error($message) {
		file_put_contents('log/PDO_errors.txt', $message, FILE_APPEND);
	}




?>



