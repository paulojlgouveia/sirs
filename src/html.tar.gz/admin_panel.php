


<html>
	<title>Auction</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="src/css/login.css">
	
	<body>
		<h1>hello admin</h1>
		


	</body>
	
</html>


