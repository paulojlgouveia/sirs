
<?php
	// Variáveis de conexão à BD
	$host="localhost";
	$user="root";
	$password="ju57 50m3 p455w0rD";
	$dbname = "auctionsDB";
	$connection = new PDO("mysql:host=" . $host. ";dbname=" . $dbname, $user, $password,
	array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
?>


